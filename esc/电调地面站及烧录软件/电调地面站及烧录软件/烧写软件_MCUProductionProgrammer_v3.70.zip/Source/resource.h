//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MCUProgrammer.rc
//
#define IDD_ABOUTBOX                    16
#define IDD_MCUPROGRAMMER_DIALOG        17
#define IDD_PROGRAMMINGSETTINGS_DIALOG  18
#define IDM_ABOUTBOX                    19
#define IDR_MAINFRAME                   20
#define IDR_MENU1                       21
#define IDS_ABOUTBOX                    22
#define IDC_BUTTON_BROWSE_BANK1         1000
#define IDC_BUTTON_BROWSE_BANK2         1001
#define IDC_BUTTON_BROWSE_BANK3         1002
#define IDC_BUTTON_BROWSE_LOG           1003
#define IDC_BUTTON_BROWSE_NOT_BANKED    1004
#define IDC_BUTTON_LOADSETTINGS         1005
#define IDC_BUTTON_PROGRAMDEVICE        1006
#define IDC_BUTTON_SAVESETTINGS         1007
#define IDC_CHECK_APPENDLOGFILE         1008
#define IDC_CHECK_ERASECODESPACE        1009
#define IDC_CHECK_FLASH_PERSIST         1010
#define IDC_CHECK_FLASHPERSIST          1011
#define IDC_CHECK_LOCK_CODE_SPACE       1012
#define IDC_CHECK_LOGTOFILE             1013
#define IDC_CHECK_SERIALIZEPARTS        1015
#define IDC_COMBO_DEBUGADAPTER          1016
#define IDC_COMBO_PARTNUMBER            1017
#define IDC_COMBO_SERIALNUMBERSIZE      1018
#define IDC_EDIT_CURRENTSERIALNUMBER    1019
#define IDC_EDIT_DEBUGADAPTER           1020
#define IDC_EDIT_HEX_BANK1              1021
#define IDC_EDIT_HEX_BANK2              1022
#define IDC_EDIT_HEX_BANK3              1023
#define IDC_EDIT_HEX_NOT_BANKED         1024
#define IDC_EDIT_HEXFILE_BANK1          1025
#define IDC_EDIT_HEXFILE_BANK2          1026
#define IDC_EDIT_HEXFILE_BANK3          1027
#define IDC_EDIT_HEXFILE_NOT_BANKED     1028
#define IDC_EDIT_LOGFILE                1029
#define IDC_EDIT_MAXSERIALNUMBER        1030
#define IDC_EDIT_NUMBERPARTSINRANGE     1031
#define IDC_EDIT_PARTNUMBER             1032
#define IDC_EDIT_READ_LOCK_BYTE         1033
#define IDC_EDIT_SERIALNUMBERCODELOCATION 1034
#define IDC_EDIT_SERIALNUMBERINCREMENT  1035
#define IDC_EDIT_STARTINGSERIALNUMBER   1036
#define IDC_EDIT_WRITE_LOCK_BYTE        1037
#define IDC_RICHEDIT_LOG                1038
#define IDC_STATIC_BANK1                1039
#define IDC_STATIC_BANK2                1040
#define IDC_STATIC_BANK3                1041
#define IDC_STATIC_LOG                  1042
#define IDC_STATIC_NOT_BANKED           1043
#define IDC_STATIC_READ_LOCK_BYTE       1044
#define IDC_STATIC_WRITE_LOCK_BYTE      1045
#define IDC_CHECK_UNICODE               1047
#define IDC_CHECK_ENDIAN                1049
#define ID_PROGRAMMENU_CONFIGUREPROGRAMMINGINFORMATION 32772
#define ID_PROGRAMMENU_EXIT             32773
#define ID_PROGRAMMENU_LOADSETTINGS     32774
#define ID_PROGRAMMENU_SAVESETTINGS     32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        23
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           1146
#endif
#endif
