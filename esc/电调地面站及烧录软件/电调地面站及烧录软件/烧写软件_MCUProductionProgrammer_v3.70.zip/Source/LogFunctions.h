
#ifndef _LOGFUNCTIONS_H_
#define _LOGFUNCTIONS_H_

void LogMessage(CRichEditCtrl* richEditCtrl, BOOL status, const char* message, BOOL logToFile, CString logFilename);

#endif _LOGFUNCTIONS_H_